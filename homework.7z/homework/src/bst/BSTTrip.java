package bst;

import java.util.Stack;

public class BSTTrip {
  private Node root;
  // inner class
  private class Node {

    private Trip trip;
    private Node left;
    private Node right;
    // constructor for Node
    private Node(Trip trip) {
      this.trip = trip;
    }

    private Integer getKey() {
      return trip.getId();
    }
  }

  // External methods
  public double findCost(Integer key) {
    Trip trip = find(key).trip;
    return trip == null ? null : trip.getDays() * trip.getFee();
  }

  public void insertTrip(Trip trip) {
    insert(trip);
  }

  public void printTrip() {
    traverseInOrder();
  }

  public double returnAverage() {
    Node root = getRoot();
    if (root == null) return 0;

    double sum = 0;
    int count = 0;
    Stack<Node> stack = new Stack<>();
    stack.push(root);

    while (stack != null && !stack.isEmpty()) {
      Node temp = stack.pop();
      count++;
      sum = sum + temp.trip.getDays() * temp.trip.getFee();
      if (temp.left != null) {
        stack.push(temp.left);
      }
      if (temp.right != null) {
        stack.push(temp.right);
      }
    }

    return sum / count;
  }

  // Internal methods
  private Node find(int key) {
    return findR(root, key);
  }

  private Node findR(Node root, int key) {
    if (root == null || root.getKey() == key) {
      return root;
    }
    if (key > root.getKey()) {
      return findR(root.right, key);
    } else {
      return findR(root.left, key);
    }
  }

  private void insert(Trip data) {
    root = insertR(root, data);
  }

  private Node insertR(Node root, Trip data) {
    if (root == null) {
      return new Node(data);
    }
    if (data.getId() < root.getKey()) {
      root.left = insertR(root.left, data);
    } else if (data.getId() > root.getKey()) {
      root.right = insertR(root.right, data);
    }
    return root;
  }

  private void traverseInOrder() {
    traverseInOrderR(root);
  }

  private void traverseInOrderR(Node root) {
    if (root != null) {
      traverseInOrderR(root.left);
      visit(root);
      traverseInOrderR(root.right);
    }
  }

  private void visit(Node root) {
    System.out.println(root.trip.toString());
  }

  private Node getRoot() {
    return root;
  }
}
