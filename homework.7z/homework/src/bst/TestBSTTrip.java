package bst;

public class TestBSTTrip {
  public static void main(String[] args) {
    BSTTrip bstTrip = new BSTTrip();
    bstTrip.insertTrip(new Trip(110, 10, 30.00));
    bstTrip.insertTrip(new Trip(101, 2, 10.00));
    bstTrip.insertTrip(new Trip(311, 5, 50.50));
    bstTrip.insertTrip(new Trip(271, 3, 25.30));

    System.out.println("ID: " + 311 + " Cost: $" + bstTrip.findCost(311));
    System.out.println("ID: " + 101 + " Cost: $" + bstTrip.findCost(101));

    bstTrip.printTrip();

    System.out.println("Average cost: $" + bstTrip.returnAverage());
  }
}
