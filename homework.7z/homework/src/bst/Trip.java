package bst;

public class Trip {
  public Trip(Integer id, int days, double fee) {
    this.id = id;
    this.days = days;
    this.fee = fee;
  }

  private Integer id;
  private int days;
  private double fee;

  public Trip(Integer id) {
    this.id = id;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public int getDays() {
    return days;
  }

  public void setDays(int days) {
    this.days = days;
  }

  public double getFee() {
    return fee;
  }

  public void setFee(double fee) {
    this.fee = fee;
  }

  @Override
  public String toString() {
    return id + " " + days + " " + fee;
  }
}
