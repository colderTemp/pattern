package sort;

public class InsertionSort {
    public int[] sortArray(int[] nums) {
        int item;
        int n = nums.length;
        int i = 0;
        int j;
        while(i < n) {
            item = nums[i];
            j = i - 1;
            while(j >= 0 && nums[j] > item) {
                nums[j + 1] = nums[j];
                j--;
            }
            nums[j + 1] = item;
            i++;
        }
        return nums;
    }
}
