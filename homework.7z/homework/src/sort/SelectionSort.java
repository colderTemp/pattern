package sort;

public class SelectionSort {
    public int[] sortArray(int[] nums) {
        int min, temp, index, j;
        int i = 0;
        int n = nums.length;
        while (i < n) {
            min = nums[i];
            index = i;
            j = i + 1;
            while(j < n) {
                if (nums[j] < min){
                    min = nums[j];
                    index = j;
                }
                j++;
            }
            if (i != index) {
                temp = nums[i];
                nums[i] = nums[index];
                nums[index] = temp;
            }
            i++;
        }
        return nums;
    }
}
