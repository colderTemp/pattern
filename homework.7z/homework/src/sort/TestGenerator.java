package sort;

import java.util.Random;

public class TestGenerator {
    public int[] generateRandomArray() {
        int[] testCase = new int[10000];
        Random random = new Random();
        for (int i = 0; i < 10000; i++) {
            testCase[i] = random.nextInt();
        }
        return testCase;
    }

    public int[] generateSortedArray() {
        int[] testCase = new int[10000];
        for (int i = 0; i < 10000; i++) {
            testCase[i] = i;
        }
        return testCase;
    }

    public int[] generateReversSortedArray() {
        int[] testCase = new int[10000];
        for (int i = 0; i < 10000; i++) {
            testCase[i] = 10000 - i;
        }
        return testCase;
    }
}
