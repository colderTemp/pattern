package sort;

import java.util.Arrays;

public class TestSort {
    public static void main(String[] args) {
        int[]num = {43, 15, 32, 7, 12, 40, 2, 7};
        InsertionSort insertionSort = new InsertionSort();
        SelectionSort selectionSort = new SelectionSort();
        TestGenerator testGenerator = new TestGenerator();
        int[]randomArray = testGenerator.generateRandomArray();
        int[]SortedArray = testGenerator.generateSortedArray();
        int[]reverseSortedArray = testGenerator.generateReversSortedArray();

        System.out.println("insertionSort: " + Arrays.toString(insertionSort.sortArray(num)));
//    Instant start = Instant.now();
//    System.out.println("insertionSort with randomArray: " + Arrays.toString(insertionSort.sortArray(randomArray)));
//    Instant end = Instant.now();
//    System.out.println("Time spend: " +  Duration.between(start, end).toMillis());
//    System.out.println("insertionSort with SortedArray: " + Arrays.toString(insertionSort.sortArray(SortedArray)));
//    System.out.println("insertionSort with reverseSortedArray: " + Arrays.toString(insertionSort.sortArray(reverseSortedArray)));
//
//    System.out.println("selectionSort: " + Arrays.toString(selectionSort.sortArray(num)));
//    System.out.println("selectionSort with randomArray: " + Arrays.toString(selectionSort.sortArray(randomArray)));
//    System.out.println("selectionSort with SortedArray: " + Arrays.toString(selectionSort.sortArray(SortedArray)));
//    System.out.println("selectionSort with reverseSortedArray: " + Arrays.toString(selectionSort.sortArray(reverseSortedArray)));
    }
}
